<!DOCTYPE html>
<html>
<head>
  <title>Form Diagnosa</title>
  <style>
    body {
  font-family: Arial, sans-serif;
  background-color: #708090;
}

.container {
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

h3 {
  margin-top: 0;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

.checkbox {
  margin-bottom: 10px;
}

input[type="checkbox"] {
  margin-right: 10px;
}

label {
  color: #555;
}

.btn {
  display: block;
  width: 100%;
  padding: 10px;
  text-align: center;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.btn:hover {
  background-color: #0056b3;
}

  </style>
  
</head>
<body>
  <div class="container">
    <h3>Pilih Gejala:</h3>
    <form action="<?php echo site_url('diagnosa/proses_diagnosa'); ?>" method="post">
      <div class="form-group">
        <?php foreach ($gejala as $g): ?>
          <div class="checkbox">
            <input type="checkbox" name="gejala[]" id="gejala_<?php echo $g->id_gejala; ?>" value="<?php echo $g->id_gejala; ?>">
            <label for="gejala_<?php echo $g->id_gejala; ?>"><?php echo $g->nama_gejala; ?></label>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="submit" class="btn">Diagnosa</button>
      <br>
      <div class="col-md-12">
            <a href="<?= base_url() ?>dashboard" class="btn btn-primary">Home</a><br><br>
        </div>
    </form>
  </div>
</body>
</html>
