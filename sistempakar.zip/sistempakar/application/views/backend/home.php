<div class="container-fluid">
<h1 class="mb-3 font-weight text-primary">Sistem Pakar Diagnosis Penyakit Paru Paru</h1>
    <!-- Content Row -->

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight text-primary">Data Penyakit</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Penyakit</th>
                            <th>Gejala</th>                           
                        </tr>
                    </thead>
                    <tbody>
                            <tr>
                                <td>1</td>
                                <td>Kanker Paru paru</td>
                                <td>Hilang Nafsu Makan, Batuk Berdarah, Penurunan Berat Badan, Batuk, Pembengkakan Leher dan Kepala, Sesak Nafas, Suara Serak</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>PNEUMONIA</td>
                                <td>Hilang Nafsu Makan, Pembengkakan Leher Dan Kepala, Sesak Nafas, Nyeri Dada, Batuk Berdahak, Kelelahan</td>
                            </tr>    
                            <tr>
                                <td>3</td>
                                <td>Tuberkulosis Paru (TBC)</td>
                                <td>Pembengkakan leher dan wajah, Demam, Batuk Lebih dari 3 Minggu, Nyeri Dada, Batuk Berdahak, Berat Badan menurun, Malaise</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Penyakit Paru Obstruktif Kronik (PPOK)</td>
                                <td>Hilang Nafsu Makan, Nafas Mengi< Batuk Lebih Dari 3 Minggu, Dahak, Sesak Nafas, Dahak Bersifat Mukoid, Dahak Bersifat Purulen</td>
                            </tr>    
                            <tr>
                                <td>5</td>
                                <td>ASMA</td>
                                <td>Nafas Mengi, Gangguan Kesadaran</td>
                            </tr>                             
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
</div>
</div>
</div>
<!-- Page Heading -->
</div>