<!DOCTYPE html>
<html>
<head>
    <title>Proses Diagnosa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #708090;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .result {
            margin-top: 30px;
            text-align: center;
        }

        .result strong {
            font-size: 24px;
            color: #333;
        }
        .btn-kembali {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 10px;
  cursor: pointer;
}

.btn-kembali:hover {
  background-color: #45a049;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Proses Diagnosa</h2>
        <p>Hasil diagnosa:</p>
        <strong><?php echo $hasil_diagnosa; ?></strong>
        <!-- Tombol Kembali -->
        <br>
<a href="<?= base_url('diagnosa'); ?>" class="btn btn-primary btn-kembali">Kembali</a>


    </div>
</body>
</html>

</html>
