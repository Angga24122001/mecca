<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_dashboard');
    }

    public function index()
    {
        $this->m_squrity->getSqurity();

        $isi['content'] = 'backend/home';
        $isi['judul'] = 'Dashboard';
        $this->load->view('backend/dashboard', $isi);
    }
}
