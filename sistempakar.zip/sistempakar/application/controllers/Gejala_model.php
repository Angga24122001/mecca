<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gejala_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function getAllGejala()
    {
        // Mengambil semua data gejala dari tabel gejala
        $query = $this->db->get('gejala');
        return $query->result();
    }

}
