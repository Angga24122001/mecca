<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penyakit_model extends CI_Model {

    public function diagnosaPenyakit($gejala)
    {
        // Mengambil data penyakit yang memiliki gejala yang dipilih
        $this->db->select('penyakit.nama_penyakit, COUNT(*) AS total_gejala');
        $this->db->from('aturan');
        $this->db->join('penyakit', 'penyakit.id_penyakit = aturan.id_penyakit');
        $this->db->where_in('aturan.id_gejala', $gejala);
        $this->db->group_by('penyakit.id_penyakit');
        $this->db->order_by('total_gejala', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get();

        // Mengembalikan hasil diagnosa
        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->nama_penyakit;
        } else {
            return 'Tidak ditemukan penyakit yang sesuai dengan gejala yang dipilih.';
        }
    }

}
