<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Diagnosa extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('gejala_model');
        $this->load->model('penyakit_model');
    }

    public function index()
    {
        // Mengambil data gejala dari model
        $data['gejala'] = $this->gejala_model->getAllGejala();

        // Menampilkan view form diagnosa
        $this->load->view('diagnosa_form', $data);
    }

 public function proses_diagnosa()
{
    // Mengambil gejala yang dipilih dari inputan checkbox
    $gejala = $this->input->post('gejala');

    // Menjalankan proses diagnosa berdasarkan gejala yang dipilih
    $hasil_diagnosa = $this->penyakit_model->diagnosaPenyakit($gejala);

    // Menampilkan hasil diagnosa
    $data['hasil_diagnosa'] = $hasil_diagnosa;
    $this->load->view('proses_diagnosa', $data);
}

}
