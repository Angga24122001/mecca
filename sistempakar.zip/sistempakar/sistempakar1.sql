-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 03:10 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempakar1`
--

-- --------------------------------------------------------

--
-- Table structure for table `aturan`
--

CREATE TABLE `aturan` (
  `id_aturan` int(11) NOT NULL,
  `id_penyakit` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aturan`
--

INSERT INTO `aturan` (`id_aturan`, `id_penyakit`, `id_gejala`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 2, 1),
(11, 2, 5),
(12, 2, 11),
(13, 2, 12),
(14, 2, 14),
(15, 2, 15),
(16, 2, 16),
(17, 3, 1),
(18, 3, 2),
(19, 3, 12),
(20, 3, 13),
(21, 3, 14),
(22, 3, 15),
(23, 3, 19),
(24, 3, 21),
(25, 4, 9),
(26, 4, 13),
(27, 4, 20),
(28, 4, 27),
(29, 4, 28),
(30, 4, 29),
(31, 4, 30),
(32, 5, 9),
(33, 5, 10),
(34, 5, 11),
(35, 5, 17),
(36, 5, 18),
(37, 5, 22),
(38, 5, 23),
(39, 5, 25);

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `kode_gejala` varchar(10) NOT NULL,
  `nama_gejala` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `kode_gejala`, `nama_gejala`) VALUES
(1, 'G01', 'HILANG NAFSU MAKAN'),
(2, 'G02', 'BATUK BERDARAH'),
(3, 'G03', 'PENURUNAN BERAT BADAN ( > 4 KG / 6 BULAN)'),
(4, 'G04', 'BATUK > 3 MINGGU TANPA RESPON TERHADAP OBAT BATUK'),
(5, 'G05', 'PEMBENGKAKAN LEHER DAN WAJAH'),
(6, 'G06', 'SESAK'),
(7, 'G07', 'SUARA SERAK'),
(8, 'G08', 'RADANG PARU KERAP BERULANG'),
(9, 'G09', 'NAFAS MENGI'),
(10, 'G10', 'GANGGUAN KESADARAN'),
(11, 'G11', 'SESAK NAFAS'),
(12, 'G12', 'DEMAM'),
(13, 'G13', 'BATUK > 3 MINGGU'),
(14, 'G14', 'NYERI DADA'),
(15, 'G15', 'BATUK BERDAHAK'),
(16, 'G16', 'KELELAHAN'),
(17, 'G17', 'MUAL MUNTAH'),
(18, 'G18', 'BASAH TELAPAK TANGAN'),
(19, 'G19', 'BERAT BADAN MENURUN'),
(20, 'G20', 'BATUK MUNCUL SEBELUM ATAU BERSAMAAN DENGAN SESAK NAFAS'),
(21, 'G21', 'MALAISE'),
(22, 'G22', 'RIWAYAT ASMA KELUARGA'),
(23, 'G23', 'SENSASI TERTARIK DI DADA'),
(24, 'G24', 'DIARE'),
(25, 'G25', 'ALERGI ASAP DAN DEBU'),
(26, 'G26', 'KERINGAT MALAM'),
(27, 'G27', 'DAHAK TIDAK BANYAK HANYA BEBERAPA SENDOK TEH PER HARI'),
(28, 'G28', 'SESAK NAPAS KETIKA MENGARAHKAN TENAGA'),
(29, 'G29', 'DAHAK BERSIFAT MUKOID (KENTAL BERWARNA HIJAU)'),
(30, 'G30', 'DAHAK BERSIFAT PURULEN (KUNING SEDIKIT CAIR) DAN BERNANAH PADA KEADAAN INFEKSI');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `kode_penyakit` varchar(10) NOT NULL,
  `nama_penyakit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `kode_penyakit`, `nama_penyakit`) VALUES
(1, 'P01', 'Kanker Paru paru'),
(2, 'P02', 'PNEUMONIA'),
(3, 'P03', 'Tuberkulosis Paru (TBC)'),
(4, 'P04', 'Penyakit Paru Obstruktif Kronik (PPOK)'),
(5, 'P05', 'ASMA');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`) VALUES
(1, 'user', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id_aturan`),
  ADD KEY `id_penyakit` (`id_penyakit`),
  ADD KEY `id_gejala` (`id_gejala`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aturan`
--
ALTER TABLE `aturan`
  MODIFY `id_aturan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id_penyakit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aturan`
--
ALTER TABLE `aturan`
  ADD CONSTRAINT `aturan_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`),
  ADD CONSTRAINT `aturan_ibfk_2` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
